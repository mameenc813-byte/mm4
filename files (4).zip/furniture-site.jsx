import React, { useState } from 'react';
import { ShoppingCart, X, Menu, Search, ChevronDown } from 'lucide-react';

export default function FurnitureStore() {
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const products = [
    {
      id: 1,
      name: 'Luxe Sectional Sofa',
      category: 'Living Room',
      price: 3499,
      image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500&h=500&fit=crop',
      description: 'Italian leather sectional with hand-stitched details',
      rating: 4.8
    },
    {
      id: 2,
      name: 'Minimalist Lounge Chair',
      category: 'Living Room',
      price: 1299,
      image: 'https://images.unsplash.com/photo-1592078615290-033ee584e267?w=500&h=500&fit=crop',
      description: 'Contemporary design with premium fabric',
      rating: 4.9
    },
    {
      id: 3,
      name: 'Platform Bed Frame',
      category: 'Bedroom',
      price: 2199,
      image: 'https://images.unsplash.com/photo-1540932239986-310128078ceb?w=500&h=500&fit=crop',
      description: 'Solid walnut with integrated lighting',
      rating: 4.7
    },
    {
      id: 4,
      name: 'Glass Dining Table',
      category: 'Dining',
      price: 1899,
      image: 'https://images.unsplash.com/photo-1578500494198-246f612d03b3?w=500&h=500&fit=crop',
      description: 'Tempered glass with oak base, seats 6',
      rating: 4.8
    },
    {
      id: 5,
      name: 'Modern Nightstand',
      category: 'Bedroom',
      price: 649,
      image: 'https://images.unsplash.com/photo-1565538810185-2f202b5fda29?w=500&h=500&fit=crop',
      description: 'Minimalist design with soft-close drawers',
      rating: 4.6
    },
    {
      id: 6,
      name: 'Premium Coffee Table',
      category: 'Living Room',
      price: 899,
      image: 'https://images.unsplash.com/photo-1532372320572-cda25629edd0?w=500&h=500&fit=crop',
      description: 'Marble top with brass accents',
      rating: 4.9
    },
    {
      id: 7,
      name: 'Upholstered Dining Chair',
      category: 'Dining',
      price: 449,
      image: 'https://images.unsplash.com/photo-1565182999555-8dd4e9a2abf8?w=500&h=500&fit=crop',
      description: 'Set of 4, velvet upholstery',
      rating: 4.7
    },
    {
      id: 8,
      name: 'Bedroom Dresser',
      category: 'Bedroom',
      price: 1599,
      image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500&h=500&fit=crop',
      description: 'Six-drawer dresser with mirror',
      rating: 4.8
    }
  ];

  const categories = [
    { name: 'Living Room', image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=300&h=300&fit=crop' },
    { name: 'Bedroom', image: 'https://images.unsplash.com/photo-1540932239986-310128078ceb?w=300&h=300&fit=crop' },
    { name: 'Dining', image: 'https://images.unsplash.com/photo-1578500494198-246f612d03b3?w=300&h=300&fit=crop' }
  ];

  const addToCart = (product) => {
    const existingItem = cartItems.find(item => item.id === product.id);
    if (existingItem) {
      setCartItems(cartItems.map(item =>
        item.id === product.id ? { ...item, qty: item.qty + 1 } : item
      ));
    } else {
      setCartItems([...cartItems, { ...product, qty: 1 }]);
    }
    setSelectedProduct(null);
  };

  const removeFromCart = (productId) => {
    setCartItems(cartItems.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId, qty) => {
    if (qty === 0) {
      removeFromCart(productId);
    } else {
      setCartItems(cartItems.map(item =>
        item.id === productId ? { ...item, qty } : item
      ));
    }
  };

  const cartTotal = cartItems.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const cartCount = cartItems.reduce((sum, item) => sum + item.qty, 0);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200 sticky top-0 z-40 bg-white">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-8 flex-1">
              <h1 className="text-2xl font-light tracking-tight">Rk.</h1>
              <nav className="hidden md:flex gap-8">
                <a href="#" className="text-sm hover:text-gray-600">Home</a>
                <a href="#" className="text-sm hover:text-gray-600">Collection</a>
                <a href="#" className="text-sm hover:text-gray-600">Inspiration</a>
                <a href="#" className="text-sm hover:text-gray-600">About</a>
              </nav>
            </div>
            <div className="flex items-center gap-4">
              <button className="p-2 hover:bg-gray-100 rounded">
                <Search size={20} />
              </button>
              <button 
                onClick={() => setCartOpen(!cartOpen)}
                className="p-2 hover:bg-gray-100 rounded relative"
              >
                <ShoppingCart size={20} />
                {cartCount > 0 && (
                  <span className="absolute top-0 right-0 bg-black text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 hover:bg-gray-100 rounded"
              >
                <Menu size={20} />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=1200&h=800&fit=crop)',
            backgroundAttachment: 'fixed'
          }}
        >
          <div className="absolute inset-0 bg-black/30"></div>
        </div>
        <div className="relative z-10 text-center text-white max-w-2xl px-4">
          <h2 className="text-6xl font-light mb-4">Elevate Your Space</h2>
          <h3 className="text-4xl font-light mb-6">The Art of Fine Living.</h3>
          <p className="text-lg mb-8 opacity-90">
            Discover curated collections of timeless furniture, crafted with uncompromising quality for the modern luxury home.
          </p>
          <div className="flex gap-4 justify-center">
            <button className="px-8 py-3 bg-white text-black hover:bg-gray-100 font-medium">
              Explore Collection
            </button>
            <button className="px-8 py-3 border border-white hover:bg-white/10">
              Book Showroom Visit
            </button>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-light mb-4">Curated Spaces</h2>
          <p className="text-gray-600 mb-12">Explore our meticulously designed collections tailored for every room in your luxury home.</p>
          <div className="grid md:grid-cols-3 gap-6">
            {categories.map((cat, idx) => (
              <div key={idx} className="relative h-64 rounded-lg overflow-hidden group cursor-pointer">
                <img src={cat.image} alt={cat.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition-colors flex items-center justify-center">
                  <div className="text-center text-white">
                    <p className="text-2xl font-light mb-2">{cat.name}</p>
                    <button className="text-sm border-b border-white hover:opacity-70">Explore</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trending Products */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-light mb-12">Trending Collection</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {products.slice(0, 8).map((product) => (
              <div key={product.id} className="group">
                <div className="relative h-64 rounded-lg overflow-hidden bg-white mb-4 cursor-pointer">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    onClick={() => setSelectedProduct(product)}
                  />
                  <button 
                    onClick={() => addToCart(product)}
                    className="absolute bottom-4 left-4 right-4 bg-black text-white py-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    Add to Cart
                  </button>
                </div>
                <h3 className="font-light text-lg mb-1">{product.name}</h3>
                <p className="text-gray-600 text-sm mb-2">{product.category}</p>
                <div className="flex justify-between items-center">
                  <span className="font-medium">${product.price.toLocaleString()}</span>
                  <span className="text-sm text-yellow-600">★ {product.rating}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Craftsmanship Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-light mb-6">Uncompromising Craftsmanship.</h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Every piece in our collection is a testament to the art of fine furniture making. We source only the most exceptional materials from around the globe, ensuring that true luxury is felt in every detail.
              </p>
              <p className="text-gray-600 mb-8 leading-relaxed">
                Our master artisans blend time-honored techniques with contemporary design sensibilities, resulting in furniture that transcends trends and becomes cherished heirlooms.
              </p>
              <button className="text-sm border-b-2 border-black hover:opacity-60 pb-1">Discover Our Story →</button>
            </div>
            <img 
              src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=600&h=600&fit=crop" 
              alt="Craftsmanship"
              className="rounded-lg"
            />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <h3 className="text-xl font-light mb-4">Rk.</h3>
              <p className="text-gray-400 text-sm">Explore our world-class premium furniture collection.</p>
            </div>
            <div>
              <h4 className="font-medium mb-4">Explore</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white">Collection</a></li>
                <li><a href="#" className="hover:text-white">Inspiration</a></li>
                <li><a href="#" className="hover:text-white">About Us</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white">Contact</a></li>
                <li><a href="#" className="hover:text-white">Shipping</a></li>
                <li><a href="#" className="hover:text-white">Returns</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Contact</h4>
              <p className="text-sm text-gray-400">123 Luxury Lane</p>
              <p className="text-sm text-gray-400">support@rk.com</p>
              <p className="text-sm text-gray-400">+1 (800) 123-4567</p>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-sm text-gray-400 text-center">
            <p>© 2026 Luxe Furnishings. All rights reserved. Crafted for Premium Lifestyles.</p>
          </div>
        </div>
      </footer>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full overflow-hidden">
            <div className="grid md:grid-cols-2">
              <img src={selectedProduct.image} alt={selectedProduct.name} className="w-full h-full object-cover" />
              <div className="p-8 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <p className="text-sm text-gray-600 mb-2">{selectedProduct.category}</p>
                      <h2 className="text-3xl font-light mb-2">{selectedProduct.name}</h2>
                    </div>
                    <button onClick={() => setSelectedProduct(null)} className="p-2 hover:bg-gray-100 rounded">
                      <X size={20} />
                    </button>
                  </div>
                  <p className="text-2xl font-medium mb-4">${selectedProduct.price.toLocaleString()}</p>
                  <p className="text-gray-600 mb-6 leading-relaxed">{selectedProduct.description}</p>
                  <div className="flex items-center gap-2 mb-6">
                    <span className="text-yellow-600">★ {selectedProduct.rating}</span>
                    <span className="text-sm text-gray-600">(248 reviews)</span>
                  </div>
                </div>
                <button 
                  onClick={() => addToCart(selectedProduct)}
                  className="w-full bg-black text-white py-3 hover:bg-gray-800 font-medium"
                >
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Shopping Cart Sidebar */}
      {cartOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex justify-end">
          <div className="bg-white w-full max-w-md h-full overflow-y-auto flex flex-col">
            <div className="flex justify-between items-center p-6 border-b">
              <h2 className="text-2xl font-light">Shopping Cart</h2>
              <button onClick={() => setCartOpen(false)} className="p-2 hover:bg-gray-100 rounded">
                <X size={20} />
              </button>
            </div>
            
            {cartItems.length === 0 ? (
              <div className="flex-1 flex items-center justify-center">
                <p className="text-gray-500">Your cart is empty</p>
              </div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex gap-4">
                      <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded" />
                      <div className="flex-1">
                        <h3 className="font-medium text-sm mb-1">{item.name}</h3>
                        <p className="text-gray-600 text-sm mb-2">${item.price.toLocaleString()}</p>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => updateQuantity(item.id, item.qty - 1)}
                            className="px-2 py-1 border border-gray-300 hover:bg-gray-100 text-sm"
                          >
                            −
                          </button>
                          <span className="w-8 text-center text-sm">{item.qty}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, item.qty + 1)}
                            className="px-2 py-1 border border-gray-300 hover:bg-gray-100 text-sm"
                          >
                            +
                          </button>
                          <button 
                            onClick={() => removeFromCart(item.id)}
                            className="ml-auto text-red-500 text-sm hover:text-red-700"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="border-t p-6 space-y-4">
                  <div className="flex justify-between text-lg font-medium">
                    <span>Total:</span>
                    <span>${cartTotal.toLocaleString()}</span>
                  </div>
                  <button className="w-full bg-black text-white py-3 hover:bg-gray-800 font-medium">
                    Proceed to Checkout
                  </button>
                  <button 
                    onClick={() => setCartOpen(false)}
                    className="w-full border border-gray-300 py-3 hover:bg-gray-50 font-medium"
                  >
                    Continue Shopping
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
